﻿using System.Security.Cryptography;

class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese cantidad 1");
        string C1 = Console.ReadLine();
        Console.WriteLine("Indique la moneda");


        Console.WriteLine("1 Quetzales ");
        Console.WriteLine("2 Dolares americanos");
        string m1 = Console.ReadLine();
        Console.Clear();

        Console.WriteLine("Ingrese cantidad 2");
        string C2 = Console.ReadLine();
        Console.WriteLine("Indique la moneda");

        Console.WriteLine("1 Quetzales ");
        Console.WriteLine("2 Dolares americanos");
        string m2 = Console.ReadLine();
        Console.Clear();

        Console.WriteLine("Ingrese cantidad 3");
        string C3 = Console.ReadLine();
        Console.WriteLine("Indique la moneda");

        Console.WriteLine("1 Quetzales ");
        Console.WriteLine("2 Dolares americanos");
        string m3 = Console.ReadLine();
        Console.Clear();

        int c11= Convert.ToInt32(C1);
        int c12 = Convert.ToInt32(C2);
        int c13 = Convert.ToInt32(C3);
        int m11 = Convert.ToInt32(m1);
        int m12 = Convert.ToInt32(m1);
        int m13 = Convert.ToInt32(m1);

        Console.Clear();   

        if(c11>c12 && c11>c13)
        {
            Console.Write(C1);

            if (m11 == 1)
            {
                Console.Write(" GTQ");
            }
            else { Console.Write("USD"); }


            Console.WriteLine(" ");


            if (c12>c13)
            {
                Console.Write(C2);
                    if (m12 == 1)
                    {
                        Console.Write(" GTQ");
                    }
                    else { Console.Write(" USD"); }
                Console.WriteLine(" ");

                 Console.Write(C3);
                
                if (m12 == 1)
                {
                    Console.Write(" GTQ");
                }
                else { Console.Write("USD"); }


            }
            else
            {
                Console.Write(C3);
               
                if (m12 == 1)
                {
                    Console.Write(" GTQ");
                }
                else { Console.Write("USD"); }
                Console.WriteLine(" ");

                Console.Write(C2);
                if (m12 == 1)
                {
                    Console.Write(" GTQ");
                }
                else { Console.Write("USD"); }


            }
        }

        if (m11== 1)
        { Console.Write(" GTQ"); 
        }




    }
    
}
