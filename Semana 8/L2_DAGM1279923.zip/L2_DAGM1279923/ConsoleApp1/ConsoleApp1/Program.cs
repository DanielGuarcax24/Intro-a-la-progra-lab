﻿
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese numero Entero: ");
        string Numero = Console.ReadLine();
        
       int n2 = Convert.ToInt32(Numero);

        if (n2 > 0)

        {
            Console.WriteLine("El numero es positivo");
        }
        
        if (n2 < 0)
        {
            Console.WriteLine("El numero es negativo");
        }

        if (n2 == 0)
        {
            Console.WriteLine("El numero es cero");
        }

        Console.Clear();

        Console.WriteLine("Ingrese un numero del 1 al 7");
        string Dia = Console.ReadLine();

        int n3 = Convert.ToInt32(Numero);

        if (n3 == 1)
        {
            Console.WriteLine("El dia correspondiente al dia es Lunes");
        }
        if (n3 == 2)
        {
            Console.WriteLine("El dia correspondiente al dia es Martes");
        }
        if (n3 == 3)
        {
            Console.WriteLine("El dia correspondiente al dia es Miercoles");
        }
        if (n3 == 4)
        {
            Console.WriteLine("El dia correspondiente al dia es Jueves");
        }
        if (n3 == 5)
        {
            Console.WriteLine("El dia correspondiente al dia es Viernes");
        }
        if (n3 == 6)
        {
            Console.WriteLine("El dia correspondiente al dia es Sabado");
        }
        if (n3 == 7)
        {
            Console.WriteLine("El dia correspondiente al dia es domingo");
        }

        Console.ReadKey();







    }
}