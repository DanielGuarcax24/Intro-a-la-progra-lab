using System.Windows.Forms;

namespace Automovil
{
    public partial class L9_DG_1279923 : Form
    {
        public L9_DG_1279923()
        {
            InitializeComponent();
        }
        Automovil objAutomovil = new Automovil();
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            int modelo;
            double precio, tipoCambio;
            string marca;


            modelo = int.Parse(txtbxModelo.Text);
            precio = double.Parse(txtbxPrecio.Text);
            tipoCambio = double.Parse(txtbxTipoCambio.Text);
            marca = txtbxMarca.Text;

            objAutomovil.DefinirMarca(marca);
            objAutomovil.DefinirModelo(modelo);
            objAutomovil.DefinirPrecio(precio);
            objAutomovil.DefiniTipoCambio(tipoCambio);

            lstboxInformacion1.Items.Clear();
        }

        private void btnAplicarDescuento_Click(object sender, EventArgs e)
        {
            double descuento = double.Parse(txtbxDescuento.Text) / 100;
            objAutomovil.AplicarDescuento(descuento);
            lstboxInformacion1.Items.Clear();
        }

        private void btnDisponibilidad_Click(object sender, EventArgs e)
        {
            objAutomovil.CambiarDisponibilidad();
            lstboxInformacion1.Items.Clear();
        }

        private void lstboxInformacion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lstboxInformacion_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMostrarInformacion_Click(object sender, EventArgs e)
        {
            objAutomovil.MostrarInformacionEnListBox(lstboxInformacion1);

        }
    }
}