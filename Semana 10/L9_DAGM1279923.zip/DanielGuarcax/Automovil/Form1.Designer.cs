﻿namespace Automovil
{
    partial class L9_DG_1279923
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            notifyIcon1 = new NotifyIcon(components);
            tbctrolLlenarDatos = new TabControl();
            tabPage1 = new TabPage();
            btnGuardar = new Button();
            txtbxTipoCambio = new TextBox();
            lblTipoCambio = new Label();
            txtbxMarca = new TextBox();
            lblMarca = new Label();
            txtbxPrecio = new TextBox();
            lblPrecio = new Label();
            txtbxModelo = new TextBox();
            lblNombre = new Label();
            tabPage2 = new TabPage();
            btnMostrarInformacion = new Button();
            btnDisponibilidad = new Button();
            btnAplicarDescuento = new Button();
            lstboxInformacion1 = new ListBox();
            txtbxDescuento = new TextBox();
            lblDescuento = new Label();
            tbctrolLlenarDatos.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // notifyIcon1
            // 
            notifyIcon1.Text = "notifyIcon1";
            notifyIcon1.Visible = true;
            // 
            // tbctrolLlenarDatos
            // 
            tbctrolLlenarDatos.Controls.Add(tabPage1);
            tbctrolLlenarDatos.Controls.Add(tabPage2);
            tbctrolLlenarDatos.Location = new Point(52, 22);
            tbctrolLlenarDatos.Margin = new Padding(3, 2, 3, 2);
            tbctrolLlenarDatos.Name = "tbctrolLlenarDatos";
            tbctrolLlenarDatos.SelectedIndex = 0;
            tbctrolLlenarDatos.Size = new Size(612, 284);
            tbctrolLlenarDatos.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btnGuardar);
            tabPage1.Controls.Add(txtbxTipoCambio);
            tabPage1.Controls.Add(lblTipoCambio);
            tabPage1.Controls.Add(txtbxMarca);
            tabPage1.Controls.Add(lblMarca);
            tabPage1.Controls.Add(txtbxPrecio);
            tabPage1.Controls.Add(lblPrecio);
            tabPage1.Controls.Add(txtbxModelo);
            tabPage1.Controls.Add(lblNombre);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Margin = new Padding(3, 2, 3, 2);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3, 2, 3, 2);
            tabPage1.Size = new Size(604, 256);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Ingreso de Datos";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(94, 181);
            btnGuardar.Margin = new Padding(3, 2, 3, 2);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(128, 40);
            btnGuardar.TabIndex = 8;
            btnGuardar.Text = "Guardar Información";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // txtbxTipoCambio
            // 
            txtbxTipoCambio.Location = new Point(145, 120);
            txtbxTipoCambio.Margin = new Padding(3, 2, 3, 2);
            txtbxTipoCambio.Name = "txtbxTipoCambio";
            txtbxTipoCambio.Size = new Size(110, 23);
            txtbxTipoCambio.TabIndex = 7;
            // 
            // lblTipoCambio
            // 
            lblTipoCambio.AutoSize = true;
            lblTipoCambio.Location = new Point(38, 122);
            lblTipoCambio.Name = "lblTipoCambio";
            lblTipoCambio.Size = new Size(91, 15);
            lblTipoCambio.TabIndex = 6;
            lblTipoCambio.Text = "Tipo de Cambio";
            // 
            // txtbxMarca
            // 
            txtbxMarca.Location = new Point(88, 89);
            txtbxMarca.Margin = new Padding(3, 2, 3, 2);
            txtbxMarca.Name = "txtbxMarca";
            txtbxMarca.Size = new Size(110, 23);
            txtbxMarca.TabIndex = 5;
            // 
            // lblMarca
            // 
            lblMarca.AllowDrop = true;
            lblMarca.AutoSize = true;
            lblMarca.Location = new Point(38, 89);
            lblMarca.Name = "lblMarca";
            lblMarca.Size = new Size(40, 15);
            lblMarca.TabIndex = 4;
            lblMarca.Text = "Marca";
            // 
            // txtbxPrecio
            // 
            txtbxPrecio.Location = new Point(88, 56);
            txtbxPrecio.Margin = new Padding(3, 2, 3, 2);
            txtbxPrecio.Name = "txtbxPrecio";
            txtbxPrecio.Size = new Size(110, 23);
            txtbxPrecio.TabIndex = 3;
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(38, 58);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(40, 15);
            lblPrecio.TabIndex = 2;
            lblPrecio.Text = "Precio";
            // 
            // txtbxModelo
            // 
            txtbxModelo.Location = new Point(88, 18);
            txtbxModelo.Margin = new Padding(3, 2, 3, 2);
            txtbxModelo.Name = "txtbxModelo";
            txtbxModelo.Size = new Size(110, 23);
            txtbxModelo.TabIndex = 1;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(29, 20);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(48, 15);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "Modelo";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(btnMostrarInformacion);
            tabPage2.Controls.Add(btnDisponibilidad);
            tabPage2.Controls.Add(btnAplicarDescuento);
            tabPage2.Controls.Add(lstboxInformacion1);
            tabPage2.Controls.Add(txtbxDescuento);
            tabPage2.Controls.Add(lblDescuento);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Margin = new Padding(3, 2, 3, 2);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3, 2, 3, 2);
            tabPage2.Size = new Size(604, 256);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Datos Automóvil";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnMostrarInformacion
            // 
            btnMostrarInformacion.Location = new Point(397, 23);
            btnMostrarInformacion.Margin = new Padding(3, 2, 3, 2);
            btnMostrarInformacion.Name = "btnMostrarInformacion";
            btnMostrarInformacion.Size = new Size(165, 22);
            btnMostrarInformacion.TabIndex = 5;
            btnMostrarInformacion.Text = "Mostrar Informacion";
            btnMostrarInformacion.UseVisualStyleBackColor = true;
            btnMostrarInformacion.Click += btnMostrarInformacion_Click;
            // 
            // btnDisponibilidad
            // 
            btnDisponibilidad.Location = new Point(70, 182);
            btnDisponibilidad.Margin = new Padding(3, 2, 3, 2);
            btnDisponibilidad.Name = "btnDisponibilidad";
            btnDisponibilidad.Size = new Size(192, 28);
            btnDisponibilidad.TabIndex = 4;
            btnDisponibilidad.Text = "Cambiar Disponibilidad";
            btnDisponibilidad.UseVisualStyleBackColor = true;
            btnDisponibilidad.Click += btnDisponibilidad_Click;
            // 
            // btnAplicarDescuento
            // 
            btnAplicarDescuento.Location = new Point(180, 20);
            btnAplicarDescuento.Margin = new Padding(3, 2, 3, 2);
            btnAplicarDescuento.Name = "btnAplicarDescuento";
            btnAplicarDescuento.Size = new Size(82, 22);
            btnAplicarDescuento.TabIndex = 3;
            btnAplicarDescuento.Text = "Aplicar";
            btnAplicarDescuento.UseVisualStyleBackColor = true;
            btnAplicarDescuento.Click += btnAplicarDescuento_Click;
            // 
            // lstboxInformacion1
            // 
            lstboxInformacion1.FormattingEnabled = true;
            lstboxInformacion1.ItemHeight = 15;
            lstboxInformacion1.Location = new Point(43, 58);
            lstboxInformacion1.Margin = new Padding(3, 2, 3, 2);
            lstboxInformacion1.Name = "lstboxInformacion1";
            lstboxInformacion1.Size = new Size(519, 109);
            lstboxInformacion1.TabIndex = 2;
            lstboxInformacion1.SelectedIndexChanged += lstboxInformacion_SelectedIndexChanged;
            // 
            // txtbxDescuento
            // 
            txtbxDescuento.Location = new Point(110, 21);
            txtbxDescuento.Margin = new Padding(3, 2, 3, 2);
            txtbxDescuento.Name = "txtbxDescuento";
            txtbxDescuento.Size = new Size(52, 23);
            txtbxDescuento.TabIndex = 1;
            // 
            // lblDescuento
            // 
            lblDescuento.AutoSize = true;
            lblDescuento.Location = new Point(28, 23);
            lblDescuento.Name = "lblDescuento";
            lblDescuento.Size = new Size(76, 15);
            lblDescuento.TabIndex = 0;
            lblDescuento.Text = "Descuento %";
            // 
            // L9_DG_1279923
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(tbctrolLlenarDatos);
            Margin = new Padding(3, 2, 3, 2);
            Name = "L9_DG_1279923";
            Text = "L9_DG_1279923";
            tbctrolLlenarDatos.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private NotifyIcon notifyIcon1;
        private TabControl tbctrolLlenarDatos;
        private TabPage tabPage1;
        private Button btnGuardar;
        private TextBox txtbxTipoCambio;
        private Label lblTipoCambio;
        private TextBox txtbxMarca;
        private Label lblMarca;
        private TextBox txtbxPrecio;
        private Label lblPrecio;
        private TextBox txtbxModelo;
        private Label lblNombre;
        private TabPage tabPage2;
        private Button btnDisponibilidad;
        private Button btnAplicarDescuento;
        private ListBox lstboxInformacion1;
        private TextBox txtbxDescuento;
        private Label lblDescuento;
        private Button btnMostrarInformacion;
    }
}