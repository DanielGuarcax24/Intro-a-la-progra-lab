﻿using System;
using System.Globalization; // Agregar el espacio de nombres para CultureInfo
using System.Windows.Forms;

namespace T9_DG_1279923
{
    public partial class Form1 : Form
    {
        private Motocicleta objMotocicleta;

        public Form1()
        {
            InitializeComponent();
            objMotocicleta = new Motocicleta();
        }

        private void btnMostrarDatos_Click(object sender, EventArgs e)
        {
            // Validar el modelo
            string inputModelo = txtModelo.Text.Trim();
            if (int.TryParse(inputModelo, out int modelo))
            {
                objMotocicleta.Modelo = modelo; // Usar la propiedad Modelo de la clase Motocicleta
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un modelo válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar la marca
            string marca = txtMarca.Text;
            objMotocicleta.Marca = marca; // Usar la propiedad Marca de la clase Motocicicleta

            // Validar el precio
            string inputPrecio = txtPrecio.Text.Trim();
            if (double.TryParse(inputPrecio, NumberStyles.AllowDecimalPoint, new CultureInfo("en-US"), out double precio))
            {
                objMotocicleta.Precio = precio; // Usar la propiedad Precio de la clase Motocicleta
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un precio válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar el IVA
            string inputIva = txtIva.Text.Trim();
            if (double.TryParse(inputIva, out double iva))
            {
                objMotocicleta.DefinirIva(iva / 100.0); // Convertir el porcentaje a valor decimal
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un IVA válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Mostrar los datos en el ListBox
            lstResultado.Items.Clear();
            lstResultado.Items.Add("Datos de la Motocicleta:");
            lstResultado.Items.Add($"Modelo:            {objMotocicleta.Modelo}");
            lstResultado.Items.Add($"Marca:             {objMotocicleta.Marca}");
            lstResultado.Items.Add($"Precio sin IVA:    ${objMotocicleta.PrecioSinIva():F2}");
            lstResultado.Items.Add($"Precio con IVA:    ${objMotocicleta.PrecioConIva():F2}");
            lstResultado.Items.Add($"Monto del IVA:     ${objMotocicleta.DevolverIva():F2}");
        }
    }
}