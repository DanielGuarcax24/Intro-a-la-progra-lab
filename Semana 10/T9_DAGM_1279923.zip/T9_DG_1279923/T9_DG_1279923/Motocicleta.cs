﻿public class Motocicleta
{
    private int modelo = 2019;
    private double precio = 1000.0;
    private string marca = "";
    private double iva = 0.12;

    public int Modelo
    {
        get { return modelo; }
        set { modelo = value; }
    }

    public string Marca
    {
        get { return marca; }
        set { marca = value; }
    }

    public double Precio
    {
        get { return precio; }
        set { precio = value; }
    }

    public string MostrarDatos()
    {
        return $"Modelo:     {modelo}\nMarca:      {marca}\nPrecio:     ${precio:F2}\nIVA:        {iva:P}";
    }

    public void DefinirIva(double nuevoIva)
    {
        if (nuevoIva >= 0.01 && nuevoIva <= 0.99)
        {
            iva = nuevoIva;
        }
    }

    public double PrecioSinIva()
    {
        return precio;
    }

    public double PrecioConIva()
    {
        return precio * (1 + iva);
    }

    public double DevolverIva()
    {
        return precio * iva;
    }
}