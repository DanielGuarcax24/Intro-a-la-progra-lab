﻿using System;

namespace Lab10_DG_1279923
{
    class Program
    {
            static void Main(string[] args)
        {
            Console.Write("Ingresa el radio del círculo: ");
            if (double.TryParse(Console.ReadLine(), out double radio))
            {
                Circulo objCirculo = new Circulo(radio);

                double perimetro = 0;
                double area = 0;
                double volumen = 0;

                objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

                Console.WriteLine("Perímetro del círculo: " + perimetro);
                Console.WriteLine("Área del círculo: " + area);
                Console.WriteLine("Volumen de la esfera: " + volumen);
            }
            else
            {
                Console.WriteLine("Entrada no válida. Por favor, ingresa un valor numérico para el radio.");
            }

            Console.WriteLine("\nAhora, ingresa los datos para un triángulo rectángulo:");
            Console.Write("Longitud del cateto a (en metros): ");
            if (double.TryParse(Console.ReadLine(), out double catetoA))
            {
                Console.Write("Ángulo opuesto al cateto a (en grados): ");
                if (double.TryParse(Console.ReadLine(), out double anguloA))
                {
                    TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloA);

                    double catetoB = objTriangulo.ObtenerCatetoB();
                    double hipotenusa = objTriangulo.ObtenerHipotenusa();
                    double anguloOpuestoA = objTriangulo.ObtenerAnguloOpuestoA();
                    double anguloOpuestoB = objTriangulo.ObtenerAnguloOpuestoB();
                    double areaTriangulo = objTriangulo.ObtenerArea();

                    Console.WriteLine("\nDatos del triángulo rectángulo:");
                    Console.WriteLine("Valor de cateto a: " + catetoA);
                    Console.WriteLine("Valor de cateto b: " + catetoB);
                    Console.WriteLine("Valor de hipotenusa: " + hipotenusa);
                    Console.WriteLine("Valor de ángulo opuesto de A: " + anguloOpuestoA);
                    Console.WriteLine("Valor de ángulo opuesto de B: " + anguloOpuestoB);
                    Console.WriteLine("Valor de área: " + areaTriangulo.ToString("F3"));
                }
                else
                {
                    Console.WriteLine("Entrada no válida. El ángulo debe ser un valor numérico en grados.");
                }
            }
            else
            {
                Console.WriteLine("Entrada no válida. La longitud del cateto a debe ser un valor numérico en metros.");
            }
        }
    }
}