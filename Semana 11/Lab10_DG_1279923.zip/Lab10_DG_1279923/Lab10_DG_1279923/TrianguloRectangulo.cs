﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_DG_1279923
{
    public class TrianguloRectangulo
    {
        private double catetoA;
        private double anguloOpuestoA;

        public TrianguloRectangulo(double catetoA, double anguloOpuestoA)
        {
            this.catetoA = catetoA;
            this.anguloOpuestoA = anguloOpuestoA;
        }

        public double ObtenerCatetoA()
        {
            return catetoA;
        }

        public double ObtenerCatetoB()
        {
            double anguloRad = anguloOpuestoA * Math.PI / 180;
            return catetoA / Math.Tan(anguloRad);
        }

        public double ObtenerHipotenusa()
        {
            return Math.Sqrt(catetoA * catetoA + ObtenerCatetoB() * ObtenerCatetoB());
        }

        public double ObtenerAnguloOpuestoA()
        {
            return anguloOpuestoA;
        }

        public double ObtenerAnguloOpuestoB()
        {
            return 90 - anguloOpuestoA;
        }

        public double ObtenerArea()
        {
            return 0.5 * catetoA * ObtenerCatetoB();
        }
    }
}
