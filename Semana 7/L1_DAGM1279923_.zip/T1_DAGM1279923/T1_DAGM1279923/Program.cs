﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo Programa");

        Console.WriteLine("Nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Edad: ");
        string Edad = Console.ReadLine();

        Console.WriteLine("Carrera: ");
        string Carrera = Console.ReadLine();

        Console.WriteLine("Carne: ");
        string Carne = Console.ReadLine();

        Console.WriteLine("Soy "+ Nombre +", tengo"+Edad+ " años y estudio la carrera de"+Carrera+". Mi numero de Carne es: "+Carne);

        Console.ReadKey();
    }
}