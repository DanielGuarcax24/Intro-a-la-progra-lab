﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su Nombre: ");
        String Nombre = Console.ReadLine();

        Console.WriteLine("Hola mundo ");
        Console.WriteLine("Soy "+ Nombre);

        /* Console.WriteLine escribe los solicitado en una
         linea independiente y al volverlo a usar cambia de linea
        mientras que Console.Write escribe todas las veces
        que se usa en una misma linea*/

        Console.Write("Hola Mundo ");
        Console.Write("Soy "+ Nombre);
        Console.ReadKey();

    }
}