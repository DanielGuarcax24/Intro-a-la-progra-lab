﻿internal class ProgramBase
{
}